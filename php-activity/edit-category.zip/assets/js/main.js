jQuery( document ).ready(function() {
    
    AOS.init();
});
