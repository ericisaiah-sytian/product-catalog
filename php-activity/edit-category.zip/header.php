<?php

    $db = Database::getInstance();
    $mysqli = $db->getConnection();

    $sql_query = "SELECT id, name FROM categories";
    $result = $mysqli->query($sql_query);

    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        // if not logged in.
        
        echo '<header>';
        echo '<div class = "container">';
            echo '<div class = "row justify-content-center align-items-center">';
            echo '<div class = "col-10">';
                echo '<ul>';
                if ($result->num_rows > 0) {
                    
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                    echo "<li><a href ='#'>" . $row["name"] . "</a></li>";
                    }
                } else {
                    echo "";
                }
                echo '</ul>';
            echo '</div>';
            echo '<div class = "col-2 text-right">';
                echo '<a href = "login.php">Log In</a>';
                echo '</div>';
            echo '</div>';
        echo '</div>';    
        echo '</header>';
    }
    else {
        // if logged in
        echo '<header>';
        echo '<div class = "container">';
            echo '<div class = "row justify-content-center align-items-center">';
            echo '<div class = "col-10">';
                echo '<ul>';
                if ($result->num_rows > 0) {
                    
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                    echo "<li><a href ='#'>" . $row["name"] . "</a></li>";
                    }
                } else {
                    echo "";
                }
                echo '</ul>';
            echo '</div>';
            echo '<div class = "col-2 text-right">';
                echo '<a href = "login.php">Log In</a>';
                echo '</div>';
            echo '</div>';
        echo '</div>';    
        echo '</header>';
        
    }
        
?>