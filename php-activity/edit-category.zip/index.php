<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang = "en">
<head>
    <title>PHP Activity - Sytian</title>
    <meta name="description" content="PHP Activity for Sytian Productions" />
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!--CSS and JS -->
    <link type="text/css" rel="stylesheet" href="assets/plugins/css/slick.css">
    <link type="text/css" rel="stylesheet" href="assets/plugins/css/aos.css">
    <link type="text/css" rel="stylesheet" href="assets/plugins/css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="assets/css/main.css">
    
    <script src="assets/plugins/js/jquery-3.6.0.min.js"></script>
    <script src="assets/plugins/js/bootstrap.min.js"></script>
    <script src="assets/plugins/js/slick.min.js"></script>
    <script src="assets/plugins/js/aos.js"></script>
    <script src="assets/js/main.js"></script>
</head>

<body>


    <?php
        require 'functions/class.Database.inc';
        $database = new Database;

    ?>

    <?php require 'header.php';  ?>

    <section class = "index">
        <?php 
            $selectproducts = "SELECT id, productname, productimage, categoryname, brandname, productprice FROM products";
            $resultproducts = $mysqli->query($selectproducts);
        ?>
        <div class = "container">
            <div class = "row justify-content-center align-items-center">
        <?php 
            if ($resultproducts->num_rows > 0) {
                // output data of each row
                while($row = $resultproducts->fetch_assoc()) {
                ?>
                    <!-- Content Loop Starts Here -->
                        <div class = "col-12 col-md-6 col-lg-3">
                            <div class = "content-wrapper product-id-<?php echo $row["id"]; ?> category-name-<?php echo $row["categoryname"]; ?>" data-aos="fade-up">
                                <img class = "product-img w-100" src = "<?php echo $row["productimage"]; ?>" alt = "<?php echo $row["productname"]; ?>">
                                <h2 class = "product-title"><?php echo $row["productname"]; ?></h2>
                                <p class = "brand-name"><?php echo $row["brandname"]; ?></p>
                                <p class = "price">₱<?php echo $row["productprice"]; ?></p>
                            </div>
                        </div>
                <?php
                }
            } else {
                echo "";
            }
        ?>
            </div>
        </div>
        <!-- Content Loop Ends Here -->   
    </section>

    
</body>